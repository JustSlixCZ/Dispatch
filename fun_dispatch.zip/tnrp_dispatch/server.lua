local ESX = exports['es_extended']:getSharedObject()
local activeAlerts = {} -- Zde ukládáme historii hlášení

-- Pomocná funkce pro online policisty a šerify
local function GetOnlineCops()
    local cops = {}
    local lspdPlayers = ESX.GetExtendedPlayers('job', 'LSPD')
    local lssdPlayers = ESX.GetExtendedPlayers('job', 'LSSD')

    for _, player in ipairs(lspdPlayers) do table.insert(cops, player) end
    for _, player in ipairs(lssdPlayers) do table.insert(cops, player) end
    return cops
end

RegisterNetEvent('tx-dispatch:triggerAlert', function(data)
    local src = source
    local activeCops = GetOnlineCops()
    
    local alertId = math.random(1000, 9999)
    
    -- Uložíme hlášení do historie na serveru (přidáme i čas)
    local alertData = {
        id = alertId,
        code = data.code or '10-99',
        title = data.title or 'Neznámá situace',
        street = data.street or 'Neznámá',
        coords = data.coords,
        time = os.date('%H:%M:%S')
    }
    table.insert(activeAlerts, 1, alertData) -- Nová hlášení budou vždy nahoře

    -- Omezíme historii na max 20 hlášení, ať se nezahlcuje paměť
    if #activeAlerts > 20 then
        table.remove(activeAlerts, #activeAlerts)
    end

    for _, xPlayer in ipairs(activeCops) do
        -- Klasické vyskakující hlášení na obrazovku (ox_lib notify)
        TriggerClientEvent('ox_lib:notify', xPlayer.source, {
            title = '🚨 DISPEČINK: ' .. alertData.code,
            description = 'Zásah: ' .. alertData.title .. '\nUlice: ' .. alertData.street .. '\n[Stiskni G pro okamžitou GPS]',
            type = 'warning',
            duration = 10000,
            position = 'top-right'
        })

        -- Aktivace rychlé klávesy G pro poslední alert
        TriggerClientEvent('tx-dispatch:receiveAlertId', xPlayer.source, alertId, alertData.coords)
        -- Blip na mapě
        TriggerClientEvent('tx-dispatch:createBlip', xPlayer.source, alertData.coords, alertData.title, data.sprite, data.color)
    end
end)

-- Callback, přes který si klient vyžádá seznam všech uložených hlášení
ESX.RegisterServerCallback('tx-dispatch:getAlerts', function(source, cb)
    cb(activeAlerts)
end)

exports('GetOnlinePolice', function()
    local activeCops = GetOnlineCops()
    return #activeCops
end)