fx_version 'cerulean'
game 'gta5'

author 'FunScripts'
description 'Dispatch by FunScripts'
version '1.1.1'

client_scripts {
    '@ox_lib/init.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}

client_exports {
    'addAlert'
}

server_exports {
    'GetOnlinePolice'
}

dependencies {
    'es_extended',
    'ox_lib'
}