local ESX = exports['es_extended']:getSharedObject()
local activeAlertCoords = nil
local alertTimer = 0

-- Rychlá reakce přes klávesu G (pro úplně nejnovější alert)
RegisterNetEvent('tx-dispatch:receiveAlertId', function(alertId, coords)
    activeAlertCoords = coords
    alertTimer = 100
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if alertTimer > 0 then
            alertTimer = alertTimer - 1
            if IsControlJustPressed(0, 47) and activeAlertCoords then -- Klávesa G
                SetNewWaypoint(activeAlertCoords.x, activeAlertCoords.y)
                lib.notify({title = 'Dispečink', description = 'GPS nastavena na nejnovější zásah!', type = 'success'})
                alertTimer = 0
                activeAlertCoords = nil
            end
        else
            activeAlertCoords = nil
            Citizen.Wait(500)
        end
    end
end)

-- Mizející blipy na mapě
RegisterNetEvent('tx-dispatch:createBlip', function(coords, title, sprite, color)
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(blip, sprite or 161)
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, color or 1)
    SetBlipAsShortRange(blip, true)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(title or "Trestný čin")
    EndTextCommandSetBlipName(blip)

    local alpha = 255
    Citizen.Wait(60000)
    while alpha > 0 do
        Citizen.Wait(100)
        alpha = alpha - 5
        SetBlipAlpha(blip, alpha)
        if alpha <= 0 then
            RemoveBlip(blip)
            break
        end
    end
end)

-- ============================================================================
-- 📊 VELKÉ DISPEČINK MENU (HISTORIE HLÁŠENÍ)
-- ============================================================================

local function OpenDispatchMenu()
    local playerData = ESX.GetPlayerData()
    
    -- Kontrola, zda je hráč policista nebo šerif
    if playerData.job and (playerData.job.name == 'LSPD' or playerData.job.name == 'LSSD') then
        
        -- Vyžádáme si historii hlášení ze serveru
        ESX.TriggerServerCallback('tx-dispatch:getAlerts', function(alerts)
            if #alerts == 0 then
                lib.notify({title = 'Dispečink', description = 'V historii nejsou žádná hlášení.', type = 'error'})
                return
            end

            local menuOptions = {}

            -- Projdeme všechna hlášení a poskládáme z nich položky v menu
            for i, alert in ipairs(alerts) do
                table.insert(menuOptions, {
                    title = '[' .. alert.code .. '] - ' .. alert.title,
                    description = 'Čas: ' .. alert.time .. ' | Ulice: ' .. alert.street,
                    icon = 'clipboard-list',
                    arrow = true,
                    onSelect = function()
                        -- Podmenu pro konkrétní vybrané hlášení
                        lib.registerContext({
                            id = 'dispatch_detail_menu',
                            title = 'Detail: ' .. alert.code,
                            menu = 'dispatch_main_menu', -- Možnost vrátit se zpět tlačítkem Zpět
                            options = {
                                {
                                    title = '📍 Nastavit GPS navigaci',
                                    description = 'Označí místo činu (' .. alert.street .. ') na mapě',
                                    icon = 'location-dot',
                                    onSelect = function()
                                        SetNewWaypoint(alert.coords.x, alert.coords.y)
                                        lib.notify({title = 'Dispečink', description = 'GPS byla úspěšně přenastavena!', type = 'success'})
                                    end
                                },
                                {
                                    title = '📋 Informace o incidentu',
                                    description = 'Zásah: ' .. alert.title .. '\nUlice: ' .. alert.street .. '\nČas nahlášení: ' .. alert.time,
                                    icon = 'info'
                                }
                            }
                        })
                        lib.showContext('dispatch_detail_menu')
                    end
                })
            end

            -- Registrace a otevření hlavního menu dispečinku
            lib.registerContext({
                id = 'dispatch_main_menu',
                title = '🚨 PŘEHLED DISPEČINKU',
                options = menuOptions
            })
            lib.showContext('dispatch_main_menu')

        end)
    else
        lib.notify({title = 'Přístup odepřen', description = 'Nejsi ve službě u policie/šerifů!', type = 'error'})
    end
end

-- Příkaz pro otevření menu do chatu nebo F8
RegisterCommand('dispatch', function()
    OpenDispatchMenu()
end, false)

-- Propojení na klávesu F6 (Můžeš změnit podle sebe, 'F6' je standardně INPUT_CELLPHONE_UP neboli klávesa 166 nebo 289)
-- Použijeme raději vestavěné FiveM mapování kláves, které je extrémně šetrné k výkonu:
RegisterKeyMapping('dispatch', 'Otevřít přehled dispečinku', 'keyboard', 'F6')

-- Export pro odesílání alertů (zůstává stejný)
exports('addAlert', function(data)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    local currentStreetHash, intersectStreetHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(currentStreetHash)

    TriggerServerEvent('tx-dispatch:triggerAlert', {
        code = data.code or '10-99',
        title = data.title or 'Neznámá situace',
        street = streetName,
        coords = coords,
        sprite = data.sprite or 161,
        color = data.color or 1
    })
end)